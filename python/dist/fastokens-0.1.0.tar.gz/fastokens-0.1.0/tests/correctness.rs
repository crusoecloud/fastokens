//! Comprehensive correctness tests comparing fastokens against HuggingFace
//! tokenizers.
//!
//! These tests download tokenizer.json files from HuggingFace Hub and verify
//! that `fastokens::Tokenizer::encode` produces identical token IDs to
//! `tokenizers::Tokenizer::encode`.
//!
//! Run with:
//!   cargo test --test correctness          (core tests only)
//!   cargo test --test correctness -- --ignored  (full model matrix)

use fastokens::Tokenizer;
use hf_hub::api::sync::Api;
use indicatif::{ProgressBar, ProgressStyle};

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

/// Models that fastokens can fully load today (BPE, no post-processor).
const CORE_MODELS: &[&str] = &["MiniMaxAI/MiniMax-M2.1"];

/// Additional models to test. These may have unsupported pipeline steps
/// (e.g. post-processors) and will be skipped gracefully when they fail
/// to load. As fastokens gains support for more pipeline components,
/// these will automatically start being tested.
const EXTENDED_MODELS: &[&str] = &[
    "deepseek-ai/DeepSeek-V3.2",
    "openai/gpt-oss-120b",
    "Qwen/Qwen3-0.6B",
    "zai-org/GLM-4.7",
    "mistralai/Mistral-Nemo-Instruct-2407",
    "Qwen/Qwen3-235B-A22B-Instruct-2507",
    "Qwen/Qwen3-Coder-480B-A35B-Instruct",
    "nvidia/NVIDIA-Nemotron-3-Nano-30B-A3B-BF16",
    "nvidia/Qwen3-Nemotron-235B-A22B-GenRM",
];

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Load both tokenizers for a given HF model name. Panics if either fails.
fn load_pair(model: &str) -> (tokenizers::Tokenizer, Tokenizer) {
    let hf = tokenizers::Tokenizer::from_pretrained(model, None)
        .unwrap_or_else(|e| panic!("{model}: failed to load HF tokenizer: {e}"));
    let ours = Tokenizer::from_model(model)
        .unwrap_or_else(|e| panic!("{model}: failed to load fastokens tokenizer: {e}"));
    (hf, ours)
}

/// Try to load both tokenizers. Returns `None` if fastokens doesn't support
/// the model yet (e.g. unsupported post-processor), allowing the caller to
/// skip gracefully.
fn try_load_pair(model: &str) -> Option<(tokenizers::Tokenizer, Tokenizer)> {
    let hf = tokenizers::Tokenizer::from_pretrained(model, None)
        .unwrap_or_else(|e| panic!("{model}: failed to load HF tokenizer: {e}"));
    match Tokenizer::from_model(model) {
        Ok(ours) => Some((hf, ours)),
        Err(e) => {
            eprintln!("{model}: skipping (fastokens: {e})");
            None
        }
    }
}

/// Encode `input` with both tokenizers and assert identical IDs.
fn assert_encode_eq(hf: &tokenizers::Tokenizer, ours: &Tokenizer, input: &str, ctx: &str) {
    let hf_ids = hf
        .encode(input, false)
        .unwrap_or_else(|e| panic!("{ctx}: HF encode({input:?}) failed: {e}"))
        .get_ids()
        .to_vec();
    let our_ids = ours
        .encode(input)
        .unwrap_or_else(|e| panic!("{ctx}: fastokens encode({input:?}) failed: {e}"));
    assert_eq!(
        our_ids, hf_ids,
        "{ctx}: ID mismatch for input {input:?}\n  ours: {our_ids:?}\n  hf:   {hf_ids:?}"
    );
}

/// Run a set of inputs against all core models.
fn check_inputs_core(inputs: &[&str]) {
    for model in CORE_MODELS {
        let (hf, ours) = load_pair(model);
        for input in inputs {
            assert_encode_eq(&hf, &ours, input, model);
        }
    }
}

/// Run a set of inputs against all extended models, skipping those that
/// fastokens doesn't support yet.
fn check_inputs_extended(inputs: &[&str]) {
    let mut tested = 0;
    for model in EXTENDED_MODELS {
        if let Some((hf, ours)) = try_load_pair(model) {
            for input in inputs {
                assert_encode_eq(&hf, &ours, input, model);
            }
            tested += 1;
        }
    }
    eprintln!("extended: tested {tested}/{} models", EXTENDED_MODELS.len());
}

// ---------------------------------------------------------------------------
// Local model
// ---------------------------------------------------------------------------

/// Try to load pair from the local tokenizer.json (if present and supported).
fn load_local_pair() -> Option<(tokenizers::Tokenizer, Tokenizer)> {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()?
        .join("models")
        .join("tokenizer.json");
    if !path.exists() {
        return None;
    }
    let hf = tokenizers::Tokenizer::from_file(&path)
        .unwrap_or_else(|e| panic!("local: HF from_file failed: {e}"));
    match Tokenizer::from_file(&path) {
        Ok(ours) => Some((hf, ours)),
        Err(e) => {
            eprintln!("local: skipping (fastokens: {e})");
            None
        }
    }
}

// =========================================================================
// Test categories
// =========================================================================

// ---------------------------------------------------------------------------
// 1. Basic encoding
// ---------------------------------------------------------------------------

#[test]
fn basic_encoding() {
    let inputs = &[
        "Hello, world!",
        "The quick brown fox jumps over the lazy dog.",
        "Machine learning is transforming the world.",
        "ALLCAPS and MiXeDcAsE",
        "multiple   spaces   between   words",
        "simple",
        "a",
        "ab",
        "abc",
        "Hello world. This is a test.",
    ];
    check_inputs_core(inputs);
}

#[test]
#[ignore]
fn basic_encoding_extended() {
    let inputs = &[
        "Hello, world!",
        "The quick brown fox jumps over the lazy dog.",
        "Machine learning is transforming the world.",
        "ALLCAPS and MiXeDcAsE",
        "multiple   spaces   between   words",
    ];
    check_inputs_extended(inputs);
}

// ---------------------------------------------------------------------------
// 2. Empty and whitespace
// ---------------------------------------------------------------------------

#[test]
fn empty_and_whitespace() {
    let inputs = &[
        "",
        " ",
        "  ",
        "   ",
        "\t",
        "\n",
        "\r\n",
        "   \t\n\r  ",
        "\0",
        "\0\0\0",
    ];
    check_inputs_core(inputs);
}

#[test]
#[ignore]
fn empty_and_whitespace_extended() {
    let inputs = &["", " ", "  ", "\t", "\n", "\r\n", "   \t\n\r  "];
    check_inputs_extended(inputs);
}

// ---------------------------------------------------------------------------
// 3. Unicode — basic multilingual plane
// ---------------------------------------------------------------------------

#[test]
fn unicode_bmp() {
    let inputs = &[
        "café résumé naïve",
        "Ελληνικά",
        "Кириллица",
        "العربية",
        "עברית",
        "हिंदी",
        "中文文本测试",
        "日本語テスト",
        "한국어 테스트",
        "ภาษาไทย",
        "Unicode: \u{00e9}\u{00e0}\u{00fc}\u{00f1}\u{00f6}",
        "CJK: \u{4f60}\u{597d}\u{4e16}\u{754c}",
    ];
    check_inputs_core(inputs);
}

#[test]
#[ignore]
fn unicode_bmp_extended() {
    let inputs = &[
        "café résumé naïve",
        "中文文本测试",
        "日本語テスト",
        "한국어 테스트",
        "Кириллица",
        "العربية",
    ];
    check_inputs_extended(inputs);
}

// ---------------------------------------------------------------------------
// 4. Unicode — supplementary planes (emoji, etc.)
// ---------------------------------------------------------------------------

#[test]
fn unicode_supplementary() {
    let inputs = &[
        "Hello 🌍🌎🌏",
        "Emoji: \u{1f600}\u{1f680}\u{2764}\u{fe0f}",
        "👨\u{200d}👩\u{200d}👧\u{200d}👦 family",
        "🏳\u{fe0f}\u{200d}🌈 flag",
        "👍🏽 thumbs up",
        "🇺🇸🇬🇧🇯🇵",
        "𝕳𝖊𝖑𝖑𝖔",
        "𐐀𐐁𐐂",
        "🎵🎶🎼🎹",
        "Text with emoji 🤖 in the middle",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 5. Unicode — combining characters and special codepoints
// ---------------------------------------------------------------------------

#[test]
fn unicode_combining() {
    let inputs = &[
        "e\u{0301}",                    // e + combining acute (= é)
        "n\u{0303}",                    // n + combining tilde (= ñ)
        "a\u{0308}",                    // a + combining diaeresis (= ä)
        "\u{200b}",                     // zero-width space
        "\u{200d}",                     // zero-width joiner
        "\u{feff}",                     // BOM
        "\u{00a0}",                     // non-breaking space
        "\u{202e}reversed\u{202c}",     // RTL override
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 6. Unicode — mixed scripts
// ---------------------------------------------------------------------------

#[test]
fn unicode_mixed() {
    let inputs = &[
        "Hello 你好 مرحبا Привет こんにちは 안녕 สวัสดี",
        "Code: x² + y² = z² (Pythagorean)",
        "Price: ¥1,000 or €850 or $999",
        "Temperature: 72°F = 22.2°C",
        "Math: ∑(i=1..n) i = n(n+1)/2",
        "Arrows: ← → ↑ ↓ ↔ ⇒ ⇐",
        "Box drawing: ┌─┬─┐│ │ │├─┼─┤",
        "ＨｅｌｌｏＷｏｒｌｄ",  // full-width ASCII
    ];
    check_inputs_core(inputs);
}

#[test]
#[ignore]
fn unicode_mixed_extended() {
    let inputs = &[
        "Hello 你好 مرحبا Привет こんにちは",
        "Price: ¥1,000 or €850 or $999",
        "ＨｅｌｌｏＷｏｒｌｄ",
    ];
    check_inputs_extended(inputs);
}

// ---------------------------------------------------------------------------
// 7. Whitespace variations
// ---------------------------------------------------------------------------

#[test]
fn whitespace_variations() {
    let inputs = &[
        "  multiple   spaces   everywhere  ",
        "    leading whitespace",
        "trailing whitespace    ",
        "line1\nline2\nline3",
        "Tabs\there\tand\there",
        "hello\r\nworld",
        "hello\rworld",
        "mixed \t \n spaces",
        " a  b   c    d     e",
        "\n\n\n",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 8. Special characters and punctuation
// ---------------------------------------------------------------------------

#[test]
fn special_chars() {
    let inputs = &[
        "Special chars: @#$%^&*()_+-=[]{}|;':\",./<>?",
        "...",
        "!!!",
        "???",
        "---",
        "___",
        "///",
        "\\\\\\",
        "((()))",
        "[[[]]]",
        "{{{}}}",
        "!@#$%^&*()",
        "`~!@#$%^&*()-_=+[]{}\\|;:'\",.<>?/",
        "a.b.c.d.e",
        "a,b,c,d,e",
        "a;b;c;d;e",
        "a:b:c:d:e",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 9. Numbers
// ---------------------------------------------------------------------------

#[test]
fn numbers() {
    let inputs = &[
        "Numbers 1234567890 and mixed ABC123def",
        "0",
        "42",
        "3.14159265358979323846",
        "1e-10",
        "-0.0",
        "-42",
        "1,000,000",
        "0x1F4A9",
        "0b10101010",
        "0o777",
        "1_000_000",
        "999999999999999999999999999999",
        "0.000000001",
        "1e100",
    ];
    check_inputs_core(inputs);
}

#[test]
fn repeated_digits() {
    let inputs = &[
        &"0".repeat(100),
        &"123456789".repeat(10),
        &"42 ".repeat(50),
    ];
    for model in CORE_MODELS {
        let (hf, ours) = load_pair(model);
        for input in inputs {
            assert_encode_eq(&hf, &ours, input, model);
        }
    }
}

// ---------------------------------------------------------------------------
// 10. Contractions and possessives
// ---------------------------------------------------------------------------

#[test]
fn contractions() {
    let inputs = &[
        "don't won't can't shouldn't",
        "I'm you're they've we'll",
        "it's that's who's what's",
        "could've should've would've",
        "let's here's there's",
        "y'all ma'am o'clock",
        "rock'n'roll",
        "John's book",
        "the dogs' toys",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 11. Code and structured text
// ---------------------------------------------------------------------------

#[test]
fn code_python() {
    let inputs = &[
        "def hello():\n    print(\"Hello, world!\")\n\nhello()",
        "import os\nimport sys\nfrom pathlib import Path\n\nif __name__ == '__main__':\n    pass",
        "\"\"\"Triple-quoted\nmulti-line\ndocstring\"\"\"",
        "lambda x: x ** 2 + 2 * x + 1",
        "[i for i in range(100) if i % 2 == 0]",
        "f\"hello {name!r} is {age:03d}\"",
        "@decorator\ndef func(a: int, b: str = 'default') -> None: ...",
        "class Foo(Bar, metaclass=Meta):\n    __slots__ = ('x', 'y')",
    ];
    check_inputs_core(inputs);
}

#[test]
fn code_other_languages() {
    let inputs = &[
        // JavaScript
        "const fn = async (x) => { return await fetch(x); };",
        "const obj = { key: 'value', nested: { a: [1, 2, 3] } };",
        // Rust
        "fn main() { println!(\"hello\"); }",
        "let v: Vec<Box<dyn Trait + Send + 'static>> = Vec::new();",
        "impl<T: Clone + Debug> Display for Wrapper<T> where T: Ord {}",
        // HTML/XML
        "<div class=\"container\"><p>Hello</p></div>",
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
        // JSON
        "{\"name\": \"test\", \"values\": [1, 2, 3], \"nested\": {\"key\": true}}",
        // SQL
        "SELECT u.name, COUNT(*) FROM users u JOIN orders o ON u.id = o.user_id GROUP BY u.name HAVING COUNT(*) > 5;",
        // Shell
        "#!/bin/bash\nfor f in *.txt; do echo \"$f\"; done",
        // Regex
        "^(?:https?://)?(?:www\\.)?([^/]+)(?:/.*)?$",
        // C
        "#include <stdio.h>\nint main() { printf(\"hello\\n\"); return 0; }",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 12. URLs, emails, paths
// ---------------------------------------------------------------------------

#[test]
fn urls_emails_paths() {
    let inputs = &[
        "https://www.example.com/path?query=value&other=123#fragment",
        "https://example.com/path?q=1&r=2",
        "ftp://files.example.com/pub/docs/readme.txt",
        "email@example.com",
        "user.name+tag@subdomain.example.co.uk",
        "/usr/local/bin/python3",
        "C:\\Users\\Admin\\Documents\\file.txt",
        "../../relative/path/to/file.rs",
        "file:///home/user/document.pdf",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 13. Repeated patterns (stress BPE merge tables)
// ---------------------------------------------------------------------------

#[test]
fn repeated_patterns() {
    let inputs: Vec<String> = vec![
        "a".repeat(1),
        "a".repeat(10),
        "a".repeat(100),
        "a".repeat(1000),
        " ".repeat(1),
        " ".repeat(50),
        " ".repeat(200),
        "\n".repeat(10),
        "\n".repeat(100),
        "ab".repeat(100),
        "abc".repeat(100),
        "hello ".repeat(50),
        "the ".repeat(200),
        "tok ".repeat(500),
    ];
    for model in CORE_MODELS {
        let (hf, ours) = load_pair(model);
        for input in &inputs {
            assert_encode_eq(&hf, &ours, input, model);
        }
    }
}

#[test]
#[ignore]
fn repeated_patterns_extended() {
    let inputs: Vec<String> = vec![
        "a".repeat(1000),
        " ".repeat(200),
        "hello ".repeat(50),
    ];
    for model in EXTENDED_MODELS {
        let (hf, ours) = load_pair(model);
        for input in &inputs {
            assert_encode_eq(&hf, &ours, input, model);
        }
    }
}

// ---------------------------------------------------------------------------
// 14. Long inputs
// ---------------------------------------------------------------------------

#[test]
fn long_inputs() {
    let inputs: Vec<String> = vec![
        // ~500 words
        "The quick brown fox jumps over the lazy dog. ".repeat(50),
        // Repeated code block
        "fn foo(x: i32) -> i32 { x + 1 }\n".repeat(100),
        // Mixed content
        format!(
            "{}{}{}",
            "Hello world. ".repeat(100),
            "中文测试。".repeat(50),
            "🤖 AI ".repeat(30),
        ),
    ];
    for model in CORE_MODELS {
        let (hf, ours) = load_pair(model);
        for input in &inputs {
            assert_encode_eq(&hf, &ours, input, model);
        }
    }
}

#[test]
#[ignore]
fn very_long_inputs() {
    let inputs: Vec<String> = vec![
        // ~5000 words
        "The quick brown fox jumps over the lazy dog. ".repeat(500),
        // Single extremely long word
        "a".repeat(50_000),
    ];
    for model in CORE_MODELS {
        let (hf, ours) = load_pair(model);
        for input in &inputs {
            assert_encode_eq(&hf, &ours, input, model);
        }
    }
}

// ---------------------------------------------------------------------------
// 15. Boundary byte values
// ---------------------------------------------------------------------------

#[test]
fn single_ascii_chars() {
    // Every printable ASCII character individually.
    for byte in 0x20u8..=0x7e {
        let input = String::from(byte as char);
        for model in CORE_MODELS {
            let (hf, ours) = load_pair(model);
            assert_encode_eq(&hf, &ours, &input, &format!("{model} byte=0x{byte:02x}"));
        }
    }
}

#[test]
fn control_chars() {
    let inputs = &[
        "\x01",     // SOH
        "\x02",     // STX
        "\x07",     // BEL
        "\x08",     // BS
        "\x0b",     // VT
        "\x0c",     // FF
        "\x1b",     // ESC
        "\x7f",     // DEL
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 16. Strings that look like special tokens
// ---------------------------------------------------------------------------

#[test]
fn special_token_lookalikes() {
    let inputs = &[
        "[CLS]",
        "[SEP]",
        "[PAD]",
        "[UNK]",
        "[MASK]",
        "<s>",
        "</s>",
        "<pad>",
        "<unk>",
        "<mask>",
        "<|endoftext|>",
        "<|im_start|>",
        "<|im_end|>",
        "<bos>",
        "<eos>",
        // Substrings / partial matches
        "<",
        ">",
        "<>",
        "<<>>",
        "[",
        "]",
        "[]",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 17. Added tokens (model-specific)
// ---------------------------------------------------------------------------

#[test]
fn added_tokens_minimax() {
    let model = "MiniMaxAI/MiniMax-M2.1";
    let (hf, ours) = load_pair(model);

    let inputs = &[
        "<filename>",
        "open <filename> for reading",
        "<filename><reponame>",
        "printf(\"%s <filename>\\n\")",
        "<think>Let me reason about this.</think>",
        "<think>load <filename> from <reponame></think>",
        "<file> is not <filename>",
        "<fim_prefix>code here<fim_suffix>more code<fim_middle>",
        // Added token at start/end
        "<filename> starts the line",
        "line ends with <filename>",
        // Only added tokens
        "<think></think>",
        // Added tokens with no text between
        "<fim_prefix><fim_suffix><fim_middle>",
        // Text that nearly matches but shouldn't
        "<filenam>",
        "<FILENAME>",
    ];
    for input in inputs {
        assert_encode_eq(&hf, &ours, input, model);
    }
}

#[test]
#[ignore]
fn added_tokens_all_models() {
    // Test common added-token-like patterns across all models.
    let inputs = &[
        "<s>hello</s>",
        "<|endoftext|>",
        "<|im_start|>system\nYou are helpful.<|im_end|>",
        "Normal text with <special> in middle",
    ];
    for model in CORE_MODELS.iter().chain(EXTENDED_MODELS.iter()) {
        if let Some((hf, ours)) = try_load_pair(model) {
            for input in inputs {
                assert_encode_eq(&hf, &ours, input, model);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 18. NFC normalization edge cases
// ---------------------------------------------------------------------------

#[test]
fn nfc_normalization() {
    let inputs = &[
        // Pre-composed vs decomposed
        "\u{00e9}",                 // é (pre-composed)
        "e\u{0301}",               // e + combining acute
        "\u{00f1}",                 // ñ (pre-composed)
        "n\u{0303}",               // n + combining tilde
        "\u{00e4}",                 // ä (pre-composed)
        "a\u{0308}",               // a + combining diaeresis
        // Hangul composition
        "\u{1100}\u{1161}",        // ᄀ + ᅡ → 가
        "\u{1100}\u{1161}\u{11a8}", // ᄀ + ᅡ + ᆨ → 각
        // Mixed
        "caf\u{0065}\u{0301}",     // café with decomposed é
        "r\u{0065}\u{0301}sum\u{0065}\u{0301}", // résumé decomposed
        // Already NFC (should be identity)
        "Hello, world!",
        "ASCII only",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 19. JSON / structured data
// ---------------------------------------------------------------------------

#[test]
fn json_data() {
    let inputs = &[
        "{}",
        "[]",
        "{\"key\": \"value\"}",
        "{\"a\": 1, \"b\": [2, 3], \"c\": {\"d\": true, \"e\": null}}",
        "[1, 2, 3, 4, 5]",
        "{\"nested\": {\"deep\": {\"very\": {\"deep\": \"value\"}}}}",
        // Escaped strings in JSON
        "{\"msg\": \"hello\\nworld\\t!\"}",
        "{\"path\": \"C:\\\\Users\\\\test\"}",
        "{\"emoji\": \"\\u{1f600}\"}",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 20. Markdown / prose
// ---------------------------------------------------------------------------

#[test]
fn markdown() {
    let inputs = &[
        "# Heading 1\n## Heading 2\n### Heading 3",
        "**bold** and *italic* and ***both***",
        "- item 1\n- item 2\n  - nested",
        "1. first\n2. second\n3. third",
        "`inline code` and ```block code```",
        "[link text](https://example.com)",
        "![image alt](image.png)",
        "> blockquote\n> continued",
        "---\n***\n___",
        "| col1 | col2 |\n|------|------|\n| a    | b    |",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 21. Adversarial / fuzz-like inputs
// ---------------------------------------------------------------------------

#[test]
fn adversarial() {
    let inputs: Vec<String> = vec![
        // Single character repeated many times
        "!".repeat(1000),
        // Alternating patterns
        "aB".repeat(500),
        "a1".repeat(500),
        // Rapidly switching scripts
        "a中b文c日d本".to_string(),
        // Lots of combining marks
        format!("a{}", "\u{0300}".repeat(20)),
        // Null bytes interspersed
        "hello\0world\0test".to_string(),
        // Very long word
        "supercalifragilisticexpialidocious".repeat(10),
        // Emoji spam
        "🤖".repeat(100),
        // Mixed whitespace chaos
        " \t\n\r \t\n\r ".repeat(50),
        // Deeply nested brackets
        format!(
            "{}hello{}",
            "(".repeat(50),
            ")".repeat(50),
        ),
    ];
    for model in CORE_MODELS {
        let (hf, ours) = load_pair(model);
        for input in &inputs {
            assert_encode_eq(&hf, &ours, input, model);
        }
    }
}

// ---------------------------------------------------------------------------
// 22. Real-world snippets
// ---------------------------------------------------------------------------

#[test]
fn real_world_snippets() {
    let inputs = &[
        // Commit message
        "fix: resolve race condition in WebSocket reconnect handler (#1234)",
        // Stack trace
        "TypeError: Cannot read properties of undefined (reading 'map')\n    at Array.map (<anonymous>)\n    at processData (app.js:42:15)",
        // Log line
        "[2024-01-15T14:30:00.000Z] INFO: Request completed in 42ms (status=200, path=/api/v2/users)",
        // SQL query
        "INSERT INTO users (name, email, created_at) VALUES ('John O''Brien', 'john@example.com', NOW());",
        // Dockerfile snippet
        "FROM python:3.12-slim AS builder\nRUN pip install --no-cache-dir -r requirements.txt\nCOPY . /app\nCMD [\"python\", \"main.py\"]",
        // YAML
        "apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: my-app\n  labels:\n    app: my-app",
        // LaTeX
        "\\documentclass{article}\n\\begin{document}\n$E = mc^2$\n\\end{document}",
        // CSV
        "name,age,city\n\"O'Brien, John\",42,\"New York\"\n\"Smith, Jane\",38,London",
        // Environment variable style
        "DATABASE_URL=postgres://user:p@ssw0rd@localhost:5432/mydb",
        // IP addresses
        "192.168.1.1 and ::1 and fe80::1%eth0",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 23. Multiline real content
// ---------------------------------------------------------------------------

#[test]
fn multiline_content() {
    let inputs = &[
        // Python function
        r#"def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result"#,
        // Rust code
        r#"use std::collections::HashMap;

fn word_count(text: &str) -> HashMap<&str, usize> {
    let mut counts = HashMap::new();
    for word in text.split_whitespace() {
        *counts.entry(word).or_insert(0) += 1;
    }
    counts
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_word_count() {
        let counts = word_count("hello world hello");
        assert_eq!(counts["hello"], 2);
        assert_eq!(counts["world"], 1);
    }
}"#,
        // English prose paragraph
        "The development of large language models has been one of the most \
         significant advances in artificial intelligence. These models, trained \
         on vast corpora of text data, demonstrate remarkable capabilities in \
         understanding and generating human language. However, they also raise \
         important questions about bias, safety, and the nature of intelligence \
         itself. Researchers continue to explore ways to make these systems more \
         reliable, interpretable, and aligned with human values.",
    ];
    check_inputs_core(inputs);
}

// ---------------------------------------------------------------------------
// 24. Consistency: encode same input multiple times
// ---------------------------------------------------------------------------

#[test]
fn deterministic() {
    let inputs = &[
        "Hello, world!",
        "The quick brown fox.",
        "def foo(): pass",
        "中文测试 emoji 🤖",
    ];
    for model in CORE_MODELS {
        let (hf, ours) = load_pair(model);
        for input in inputs {
            let first = ours
                .encode(input)
                .unwrap_or_else(|e| panic!("{model}: {e}"));
            for _ in 0..10 {
                let again = ours
                    .encode(input)
                    .unwrap_or_else(|e| panic!("{model}: {e}"));
                assert_eq!(first, again, "{model}: non-deterministic encode for {input:?}");
            }
            // Also confirm HF is the same
            let hf_ids = hf
                .encode(*input, false)
                .unwrap()
                .get_ids()
                .to_vec();
            assert_eq!(first, hf_ids, "{model}: encode != HF for {input:?}");
        }
    }
}

// ---------------------------------------------------------------------------
// 25. from_file (local model)
// ---------------------------------------------------------------------------

#[test]
fn local_model_basic() {
    let Some((hf, ours)) = load_local_pair() else {
        eprintln!("Skipping local model test (no models/tokenizer.json)");
        return;
    };
    let inputs = &[
        "Hello, world!",
        "def main():\n    print('hello')",
        "The capital of France is Paris.",
        "🤖 AI is here!",
        "Mixed: Hello 你好世界",
        "",
        " ",
        "Special chars: @#$%^&*()",
    ];
    for input in inputs {
        assert_encode_eq(&hf, &ours, input, "local");
    }
}

// ---------------------------------------------------------------------------
// 26. from_file matches from_model (same model)
// ---------------------------------------------------------------------------

#[test]
fn from_file_matches_from_model() {
    let model = "MiniMaxAI/MiniMax-M2.1";
    let api = Api::new().unwrap();
    let repo = api.model(model.to_string());
    let json_path = repo.get("tokenizer.json").unwrap();

    let from_model = Tokenizer::from_model(model).unwrap();
    let from_file = Tokenizer::from_file(&json_path).unwrap();

    let inputs = &[
        "Hello, world!",
        "The quick brown fox jumps over the lazy dog.",
        "中文测试",
        "<filename>test</filename>",
        "",
        " ",
    ];

    for input in inputs {
        let model_ids = from_model.encode(input).unwrap();
        let file_ids = from_file.encode(input).unwrap();
        assert_eq!(
            model_ids, file_ids,
            "from_model vs from_file mismatch for {input:?}"
        );
    }
}

// ---------------------------------------------------------------------------
// 27. Token count agreement
// ---------------------------------------------------------------------------

#[test]
fn token_count_agreement() {
    // Verify not just IDs match, but the count of tokens.
    let texts: Vec<String> = vec![
        "short".into(),
        "a medium length sentence with several words in it".into(),
        "A ".repeat(200),
        "hello world ".repeat(100),
    ];
    for model in CORE_MODELS {
        let (hf, ours) = load_pair(model);
        for text in &texts {
            let hf_len = hf.encode(text.as_str(), false).unwrap().get_ids().len();
            let our_len = ours.encode(text).unwrap().len();
            assert_eq!(
                our_len, hf_len,
                "{model}: token count mismatch for {len}-char input: ours={our_len}, hf={hf_len}",
                len = text.len(),
            );
        }
    }
}

// ---------------------------------------------------------------------------
// 28. File input (line-by-line)
// ---------------------------------------------------------------------------

/// Test every line of an external file against HuggingFace.
///
/// Set `FASTOKENS_INPUT_FILE` to the path of a text file. Each line is encoded
/// separately and compared. Optionally set `FASTOKENS_MODEL` to a HuggingFace
/// model name (defaults to the first core model).
///
/// Run with:
///   FASTOKENS_INPUT_FILE=corpus.txt cargo test --test correctness file_input -- --nocapture
#[test]
fn file_input() {
    let path = match std::env::var("FASTOKENS_INPUT_FILE") {
        Ok(p) => p,
        Err(_) => {
            eprintln!("Skipping file_input test (FASTOKENS_INPUT_FILE not set)");
            return;
        }
    };
    let model = std::env::var("FASTOKENS_MODEL")
        .unwrap_or_else(|_| CORE_MODELS[0].to_string());

    let (hf, ours) = load_pair(&model);

    let content = std::fs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("failed to read {path}: {e}"));

    let total = content.lines().count() as u64;
    let pb = ProgressBar::new(total);
    pb.set_style(
        ProgressStyle::with_template(
            "{bar:40.cyan/blue} {pos}/{len} lines [{elapsed_precise}<{eta_precise}, {per_sec}] {msg}",
        )
        .unwrap(),
    );

    let mut tested = 0u64;
    let mut failed = 0u64;
    for (i, line) in content.lines().enumerate() {
        let lineno = i + 1;
        let hf_enc = hf
            .encode(line, false)
            .unwrap_or_else(|e| panic!("{path}:{lineno}: HF encode failed: {e}"));
        let hf_ids = hf_enc.get_ids().to_vec();
        let our_ids = ours
            .encode(line)
            .unwrap_or_else(|e| panic!("{path}:{lineno}: fastokens encode failed: {e}"));
        if our_ids != hf_ids {
            pb.suspend(|| {
                eprintln!(
                    "MISMATCH {path}:{lineno}: {line:?}\n  ours: {our_ids:?}\n  hf:   {hf_ids:?}"
                );
            });
            failed += 1;
            pb.set_message(format!("{failed} mismatches"));
        }
        tested += 1;
        pb.set_position(tested);
    }
    pb.finish_with_message(format!("{tested} lines, {failed} mismatches"));
    assert_eq!(failed, 0, "{failed}/{tested} lines mismatched");
}

// ---------------------------------------------------------------------------
// 29. Full model matrix (ignored — slow)
// ---------------------------------------------------------------------------

#[test]
#[ignore]
fn full_model_matrix() {
    let inputs = &[
        "",
        " ",
        "Hello, world!",
        "The quick brown fox jumps over the lazy dog.",
        "  multiple   spaces   everywhere  ",
        "Line one\nLine two\nLine three",
        "Tabs\there\tand\tthere",
        "Special chars: @#$%^&*()_+-=[]{}|;':\",./<>?",
        "Unicode: éàüñö",
        "CJK: 你好世界",
        "Emoji: 😀🚀❤️",
        "Numbers 1234567890 and mixed ABC123def",
        "{\"key\": \"value\", \"n\": 42}",
        "Code: fn main() { println!(\"hello\"); }",
        "URLs: https://example.com/path?q=1&r=2",
        "Repeated: aaaaaaaaaa bbbbbbbbbb",
        "Contractions: don't won't I'm you're",
        "<s>hello</s>",
        "def f(x):\n    return x * 2\n",
        "🤖 AI and 中文 mixed with English text!",
    ];
    let mut tested = 0;
    for model in CORE_MODELS.iter().chain(EXTENDED_MODELS.iter()) {
        if let Some((hf, ours)) = try_load_pair(model) {
            for input in inputs {
                assert_encode_eq(&hf, &ours, input, model);
            }
            tested += 1;
        }
    }
    assert!(tested >= 1, "no models could be loaded at all");
    eprintln!(
        "full matrix: tested {tested}/{} models",
        CORE_MODELS.len() + EXTENDED_MODELS.len()
    );
}
